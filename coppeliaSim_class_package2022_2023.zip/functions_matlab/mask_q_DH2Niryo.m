
%----------------------------------%
%                                  %
%   Mask JointPosition DH2Niryo     %
%                                  %
%----------------------------------%



function q_Niryo = mask_q_DH2Niryo(q)
  
    q_Niryo(1) = q(1);
    q_Niryo(2) = q(2);
    q_Niryo(3) = q(3);
    q_Niryo(4) = q(4);
    q_Niryo(5) = q(5);
    q_Niryo(6) = q(6);   

end
